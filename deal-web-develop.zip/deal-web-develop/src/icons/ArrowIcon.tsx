import * as React from 'react';
import {SVGProps} from 'react';

const ArrowIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width={16}
    height={10}
    fill="none"
    {...props}>
    <path
      fill="#2E3132"
      fillRule="evenodd"
      d="M9.06 9.06a1.5 1.5 0 0 1-2.12 0L1.282 3.405a1.5 1.5 0 1 1 2.12-2.122L8 5.88l4.596-4.597a1.5 1.5 0 0 1 2.122 2.122L9.06 9.06Z"
      clipRule="evenodd"
    />
  </svg>
);
export default ArrowIcon;
