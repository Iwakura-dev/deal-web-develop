import * as React from 'react';
import {SVGProps} from 'react';

const WalletIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width={149}
    height={148}
    fill="none"
    {...props}>
    <path
      fill="#A3ADAF"
      fillRule="evenodd"
      d="M117.667 30.763V37C124.478 37 130 42.522 130 49.333V111c0 6.812-5.522 12.333-12.333 12.333H31.333C24.522 123.333 19 117.812 19 111V49.333c0-6.441 5.148-12.289 11.181-14.013l67.834-19.38c9.848-2.814 19.652 4.58 19.652 14.823ZM96.083 70.917a9.25 9.25 0 1 0 0 18.5 9.25 9.25 0 0 0 0-18.5Zm9.25-40.154a3.084 3.084 0 0 0-3.439-3.064l-.491.1L69.197 37h36.136v-6.237Z"
      clipRule="evenodd"
    />
  </svg>
);
export default WalletIcon;
