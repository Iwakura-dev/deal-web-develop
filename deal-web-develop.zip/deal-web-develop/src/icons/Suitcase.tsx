import * as React from 'react';
import {SVGProps} from 'react';

const Suitcase = (props: SVGProps<SVGSVGElement>) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width={20}
    height={18}
    fill="none"
    {...props}>
    <path
      fill="#2E3132"
      d="M5 18h10V4h-1V2.5A2.5 2.5 0 0 0 11.5 0h-3A2.5 2.5 0 0 0 6 2.5V4H5v14ZM8 2.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5V4H8V2.5ZM17 4v14a3 3 0 0 0 3-3V7a3 3 0 0 0-3-3ZM3 4a3 3 0 0 0-3 3v8a3 3 0 0 0 3 3V4Z"
    />
  </svg>
);
export default Suitcase;
