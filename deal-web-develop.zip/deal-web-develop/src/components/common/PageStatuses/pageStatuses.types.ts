export enum PageStatusesEnum {
  notFound = 'NOT_FOUNDS',
  noInternet = 'NO_INTERNET',
  serverError = 'SERVER_ERROR',
  somethingWrong = 'SOMETHING_WRONG',
  connectWallet = 'CONNECT_WALLET',
}
