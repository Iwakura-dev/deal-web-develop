export enum ButtonTypes {
  light = 'LIGHT',
  violet = 'VIOLET',
  gray = 'GRAY',
}
