import React, {useCallback, useEffect} from 'react';
import {useTronWebService} from '../../../common/hooks';
import {useI18n} from '../../../i18n';
import CloseIcon from '../../../icons/CloseIcon';
import TronLink from '../../../icons/TronLink';
import {useCryptoStore} from '../../../store/cryptoStore';
import {useUiStore} from '../../../store/uiStore';
import {Portal} from '../Portal';
import styles from './styles.module.scss';
interface AuthModalProps {
  closeModalFn: VoidFunction;
}

export const AuthModal = ({closeModalFn}: AuthModalProps) => {
  const i18n = useI18n();
  const {setProfile} = useCryptoStore(state => state);
  const {errorMessage, setErrorMessage, clearErrorMessage} = useUiStore(
    state => state,
  );
  const tronWebService = useTronWebService();

  useEffect(() => {
    return () => {
      clearErrorMessage();
    };
  }, []);

  const onConnect = useCallback(async () => {
    if (tronWebService) {
      try {
        const address = tronWebService.getDefaultAddress();
        const balance = await tronWebService.getBalanceAndConvert();

        setProfile({
          address: address,
          balance: balance,
          network: null,
        });

        closeModalFn();
      } catch (e) {
        setErrorMessage(i18n.t('common.connectionError'));
      }
    } else {
      setErrorMessage(i18n.t('common.extensionError'));
    }
  }, [tronWebService]);

  return (
    <Portal overlayClickFn={closeModalFn}>
      <div className={styles.modal} onClick={e => e.stopPropagation()}>
        <div className={styles.modalHeader}>
          <p className={styles.title}>{i18n.t('common.connectWalletTitle')}</p>
          <CloseIcon cursor={'pointer'} onClick={closeModalFn} />
        </div>
        <div className={styles.errorBlock}>
          <span>{errorMessage}</span>
        </div>
        <div className={styles.tronLink} onClick={onConnect}>
          <TronLink />
          <span>TronLink</span>
        </div>
      </div>
    </Portal>
  );
};

export default AuthModal;
