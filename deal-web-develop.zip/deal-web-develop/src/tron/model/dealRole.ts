export enum DealRole {
  Maker,
  Taker,
  Arbiter,
}
