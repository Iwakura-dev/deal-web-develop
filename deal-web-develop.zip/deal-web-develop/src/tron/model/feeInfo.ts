export type FeeInfo = {
  arbiterFeeInNormal: number;
  arbiterFeeInDispute: number;
  arbiterSentToTaker: number;
};
